# Android_Lab2
Лабораторная работа 2

![Screenshot](screenshot1.png)
